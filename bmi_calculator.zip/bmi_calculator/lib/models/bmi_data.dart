import 'package:http/http.dart' as http;
import 'dart:convert';
class BMIModel {
  final double weight;
  final double height;
  final double bmi;

  BMIModel({
    required this.weight,
    required this.height,
    required this.bmi,
  });

  factory BMIModel.fromJson(Map<String, dynamic> json) {
    return BMIModel(
      weight: json['weight'],
      height: json['height'],
      bmi: json['bmi'],
    );
  }
}

class BMIService {
  static const String apiUrl = 'http://127.0.0.1:8000/api/calculate_bmi/';

  Future<BMIModel> calculateBMI(double weight, double height) async {
    final response = await http.post(
      Uri.parse(apiUrl),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'weight': weight, 'height': height}),
    );

    if (response.statusCode == 200) {
      return BMIModel.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Failed to calculate BMI');
    }
  }
}
