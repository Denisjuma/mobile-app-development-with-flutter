package com.example.calculate_circle_area

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
