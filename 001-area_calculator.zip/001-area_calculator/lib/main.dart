import 'package:flutter/material.dart';
import 'dart:math';
import 'package:flutter/services.dart';
void main() {
  runApp( const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Home(),
  ));
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  TextEditingController radiusController = TextEditingController();
  String result = '';

  void calculateArea(){
    double radius = double.tryParse(radiusController.text) ?? 0;
    double area = pi * pow(radius, 2);
    setState(() {
      result = 'Area of circle is: ${area.toStringAsFixed(2)} m\u00B2';
      showPopup(context, result);
    });
  }

  void showPopup(BuildContext context, String message){
    showDialog(
      context: context,
      builder: (BuildContext context){
        return AlertDialog(
          title:const  Text('Result'),
          content: Text(message),
          actions: [
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child:const  Text('ok'),
            ),
          ],
        );
    },
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.blueAccent,
          title:const Text(
            'Area Calculator',
            style: TextStyle(
              color: Colors.white,
            ),
          ),
          centerTitle: true,
        ),
        body: Center(
          child: Padding(
            padding:const  EdgeInsets.all(10.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                TextField(
                  controller: radiusController,
                  keyboardType: TextInputType.number,
                  inputFormatters: <TextInputFormatter>[
                    FilteringTextInputFormatter.digitsOnly,
                  ],
                  decoration:const  InputDecoration(
                    hintText: 'Enter radius(in meter)',
                  ),
                ),
                const  SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: (){
                    calculateArea();
                  },
                  style: ElevatedButton.styleFrom(
                    padding:const  EdgeInsets.symmetric(vertical: 20.0),
                    backgroundColor: Colors.blueAccent,// Increase vertical padding
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5.0),
                      // Make it flat by setting borderRadius to 0,
                    ),
                  ),
                  child:const  Text(
                      'calculate',
                    style: TextStyle(
                    color: Colors.white, // Set the text color
                  ),
                  ),
                ),
              ],
            ),
        ),
        ),
    );
  }
}
