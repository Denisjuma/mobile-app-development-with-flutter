void main() {
  greetUser('world!');
}

void greetUser(String name) {
  print('Hello $name');
}
