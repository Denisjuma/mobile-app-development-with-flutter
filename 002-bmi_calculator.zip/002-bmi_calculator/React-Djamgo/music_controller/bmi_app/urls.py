from django.urls import path
from .views import BMICalculateAPIView

urlpatterns = [
    path('calculate_bmi/', BMICalculateAPIView.as_view(), name='calculate_bmi'),
]
