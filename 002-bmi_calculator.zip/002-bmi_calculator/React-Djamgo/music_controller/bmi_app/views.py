from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

class BMICalculateAPIView(APIView):
    def post(self, request, *args, **kwargs):
        try:
            weight = float(request.data.get('weight', 0))
            height = float(request.data.get('height', 0))

            if weight <= 0 or height <= 0:
                return Response({'error': 'Invalid weight or height'}, status=status.HTTP_400_BAD_REQUEST)

            bmi = weight / (height ** 2)

            # Categorize BMI
            if bmi < 18.5:
                category = 'Underweight'
            elif 18.5 >= bmi <= 24.9:
                category = 'Normal weight'
            elif 25 >= bmi <= 29.9:
                category = 'Overweight'
            elif 30 >= bmi <= 34.9:
                category = 'Obese (Class 1)'
            elif 35 >= bmi <= 39.9:
                category = 'Obese (Class 2)'
            else:
                category = 'Morbidly Obese'

            result = {
                'weight': weight,
                'height': height,
                'bmi': bmi,
                'category': category,
            }

            return Response(result, status=status.HTTP_200_OK)

        except Exception as e:
            print(f'Error calculating BMI: {e}')
            return Response({'error': 'Failed to calculate BMI'}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
