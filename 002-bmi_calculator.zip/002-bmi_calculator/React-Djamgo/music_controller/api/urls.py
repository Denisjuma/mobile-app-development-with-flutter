from . import views
from django.urls import path

urlpatterns = [
    path('room/',views.RoomView.as_view()),
]
